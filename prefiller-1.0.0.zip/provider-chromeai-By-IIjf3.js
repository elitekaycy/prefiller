var A=Object.defineProperty;var R=(r,e,t)=>e in r?A(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var p=(r,e,t)=>R(r,typeof e!="symbol"?e+"":e,t);import{z as c}from"./vendor-C2akVea8.js";const d={GROQ_MODEL:"llama-3.3-70b-versatile",CLAUDE_MODEL:"claude-3-5-sonnet-20241022",DEFAULT_TEMPERATURE:.4,DEFAULT_MAX_TOKENS:1024,DEFAULT_TOP_K:3,DEFAULT_TOP_P:1},D={GROQ:"https://api.groq.com/openai/v1/chat/completions",CLAUDE:"https://api.anthropic.com/v1/messages",GEMINI:"https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent"},P={GROQ:"https://console.groq.com/keys",CLAUDE:"https://console.anthropic.com/account/keys",GEMINI:"https://aistudio.google.com/app/apikey",CHROME_AI:"chrome://flags/#prompt-api-for-gemini-nano"},S={groq:"Groq",claude:"Anthropic Claude",gemini:"Google Gemini",chromeai:"Chrome AI"},_={groq:"Ultra-fast FREE AI powered by Llama 3.3 70B (30 req/min free tier)",claude:"Anthropic's helpful, harmless, and honest AI assistant",gemini:"Google's advanced AI model with strong reasoning capabilities",chromeai:"Free built-in AI that runs locally in Chrome (Gemini Nano)"},C={DEFAULT_DAILY_LIMIT:100,WARNING_THRESHOLD:.8};class f{static buildFormPrompt(e,t){let a=`Based on the following personal information, generate appropriate responses for form fields.

`;return a+=`Personal Information:
${e}

`,a+=`Form Fields to Fill:
`,t.forEach((o,n)=>{const s=o.label||o.placeholder||`Field ${n+1}`;a+=`${n+1}. ${s} (${o.type})`,o.description&&(a+=` - ${o.description}`),o.required&&(a+=" [Required]"),a+=`
`}),a+=`
Instructions:
- Provide realistic, professional responses based on the personal information
- For email fields, use a professional email format
- For phone numbers, use format like (555) 123-4567
- For dates, use MM/DD/YYYY format
- Keep responses concise and appropriate for form fields
- If you don't have enough information for a field, respond with "[SKIP]"
- Format your response as a numbered list matching the field numbers above

Example format:
1. John Doe
2. john.doe@email.com
3. (555) 123-4567
4. [SKIP]

Your responses:`,a}static parseFormResponse(e,t){const a=e.split(`
`).filter(n=>n.trim()),o=[];for(let n=0;n<t;n++)o.push("");return a.forEach(n=>{const s=n.match(/^(\d+)\.\s*(.+)$/);if(s){const i=parseInt(s[1])-1,m=s[2].trim();i>=0&&i<t&&(o[i]=m==="[SKIP]"?"":m)}}),o}static buildStructuredFormPrompt(e,t){return`You are an expert form-filling AI assistant with advanced reasoning capabilities.

=== YOUR TASK ===
Analyze the provided personal information and generate accurate, contextual responses for form fields.
You MUST provide responses in a strict JSON format with confidence scores and reasoning.

=== PERSONAL INFORMATION ===
${e}

=== FORM FIELDS ===
${t.map((o,n)=>`
Field ${n+1}:
  Label: ${o.label||"Unknown"}
  Type: ${o.type}
  Placeholder: ${o.placeholder||"None"}
  Description: ${o.description||"None"}
  Context: ${o.context||"None"}
  Required: ${o.required}
  ${o.options?`Options: [${o.options.slice(0,20).join(", ")}${o.options.length>20?"...":""}]`:""}
  ${o.pattern?`Pattern: ${o.pattern}`:""}
  ${o.maxLength?`Max Length: ${o.maxLength}`:""}
`).join(`
`)}

=== RESPONSE FORMAT (STRICT JSON) ===
{
  "fields": [
    {
      "fieldIndex": 1,
      "value": "actual value to fill",
      "confidence": 95,
      "reasoning": "Found 'John Doe' in resume contact section",
      "source": "resume.pdf:contact",
      "needsReview": false
    }
  ],
  "overallConfidence": 90,
  "documentsSummary": "Resume with software engineering experience"
}

=== CONFIDENCE SCORING (0-100) ===
- 90-100: Direct exact match found in documents
- 70-89: Strong inference from clear context
- 50-69: Reasonable guess from related info
- 30-49: Weak inference, multiple possibilities
- 0-29: No relevant information, speculation

Set needsReview: true when confidence < 70 or field is required but uncertain.

=== FIELD TYPE HANDLING ===
- TEXT/EMAIL/TEL: Extract EXACT values from documents
- SELECT: Choose BEST matching option semantically
- DATE: Use MM/DD/YYYY format
- NUMBER: Respect min/max constraints
- If no info: value="", confidence=0, needsReview=true

=== EXAMPLES ===

Example 1 - Direct Match:
Document: "Email: john@gmail.com"
Field: Email input (required)
Response: {
  "fieldIndex": 1,
  "value": "john@gmail.com",
  "confidence": 100,
  "reasoning": "Email found in contact section",
  "source": "resume.pdf:line-2",
  "needsReview": false
}

Example 2 - Inference:
Document: "Worked 2018-2023 at Google, 2023-2025 at Microsoft"
Field: Years of Experience (number)
Response: {
  "fieldIndex": 2,
  "value": "7",
  "confidence": 85,
  "reasoning": "Calculated: 5 years Google + 2 years Microsoft",
  "source": "resume.pdf:experience",
  "needsReview": false
}

Example 3 - No Information:
Field: LinkedIn URL
Document: No LinkedIn mentioned
Response: {
  "fieldIndex": 3,
  "value": "",
  "confidence": 0,
  "reasoning": "No LinkedIn URL found in documents",
  "source": "none",
  "needsReview": true
}

Generate ONLY the JSON object, no other text:`}static parseStructuredFormResponse(e,t){try{const a=e.match(/\{[\s\S]*\}/);if(!a)throw new Error("No JSON found in response");const o=JSON.parse(a[0]);if(!o.fields||!Array.isArray(o.fields))throw new Error("Invalid response structure");const n=new Map(o.fields.map(i=>[i.fieldIndex,i])),s=[];for(let i=1;i<=t;i++)s.push(n.get(i)||{fieldIndex:i,value:"",confidence:0,reasoning:"No response generated",source:"none",needsReview:!0});return{fields:s,overallConfidence:o.overallConfidence||0,documentsSummary:o.documentsSummary||""}}catch(a){return console.error("JSON parse failed:",a),this.fallbackParsing(e,t)}}static fallbackParsing(e,t){return{fields:this.parseFormResponse(e,t).map((o,n)=>({fieldIndex:n+1,value:o,confidence:o?50:0,reasoning:"Parsed from legacy format",source:"unknown",needsReview:!0})),overallConfidence:50,documentsSummary:"Legacy format response"}}}var u=(r=>(r.INVALID_API_KEY="INVALID_API_KEY",r.RATE_LIMITED="RATE_LIMITED",r.QUOTA_EXCEEDED="QUOTA_EXCEEDED",r.AUTH_ERROR="AUTH_ERROR",r.NETWORK_ERROR="NETWORK_ERROR",r.UNAVAILABLE="UNAVAILABLE",r.UNKNOWN="UNKNOWN",r))(u||{});class l extends Error{constructor(e,t,a,o){super(t),this.code=e,this.provider=a,this.originalError=o,this.name="ProviderError"}getUserMessage(){switch(this.code){case"INVALID_API_KEY":return`Invalid API key for ${this.provider}. Please check your API key in settings.`;case"RATE_LIMITED":return`Rate limit exceeded for ${this.provider}. Please wait a moment and try again.`;case"QUOTA_EXCEEDED":return`Quota exceeded for ${this.provider}. Please check your account or try a different provider.`;case"AUTH_ERROR":return`Authentication failed for ${this.provider}. Please verify your API key.`;case"NETWORK_ERROR":return`Network error connecting to ${this.provider}. Please check your internet connection.`;case"UNAVAILABLE":return`${this.provider} is currently unavailable. Please try again later.`;default:return`An error occurred with ${this.provider}: ${this.message}`}}isRetryable(){switch(this.code){case"INVALID_API_KEY":case"AUTH_ERROR":case"QUOTA_EXCEEDED":return!1;case"NETWORK_ERROR":case"RATE_LIMITED":case"UNAVAILABLE":case"UNKNOWN":return!0;default:return!0}}}const E={maxRetries:3,baseDelayMs:1e3,maxDelayMs:3e4};class b extends Error{constructor(e,t){super(e),this.originalError=t,this.name="RetryableError"}}class g extends Error{constructor(e,t){super(e),this.originalError=t,this.name="NonRetryableError"}}function x(r){var a,o,n;if(r instanceof l)return r.isRetryable();const e=[400,401,403,404,405,422],t=[408,429,500,502,503,504];if(r.status||r.statusCode){const s=r.status||r.statusCode;if(e.includes(s))return!1;if(t.includes(s))return!0}return(a=r.message)!=null&&a.toLowerCase().includes("network")||(o=r.message)!=null&&o.toLowerCase().includes("fetch")||(n=r.message)!=null&&n.toLowerCase().includes("timeout")||r.name==="NetworkError"||r.name==="TimeoutError"||r instanceof b?!0:!(r instanceof g)}function y(r,e){const t=e.baseDelayMs*Math.pow(2,r),a=t*.25*Math.random(),o=t+a;return Math.min(o,e.maxDelayMs)}function I(r){return new Promise(e=>setTimeout(e,r))}async function w(r,e=E){let t;for(let a=0;a<=e.maxRetries;a++)try{if(a>0){const o=y(a-1,e);await I(o)}return await r()}catch(o){if(t=o instanceof Error?o:new Error(String(o)),!x(o))throw new g(`Non-retryable error: ${t.message}`,t);if(a===e.maxRetries)throw new Error(`Operation failed after ${e.maxRetries} retries: ${t.message}`,{cause:t});e.onRetry&&e.onRetry(a+1,e.maxRetries,t)}throw t}const M={ENTER:"Enter",SPACE:" ",ESCAPE:"Escape",ARROW_UP:"ArrowUp",ARROW_DOWN:"ArrowDown",ARROW_LEFT:"ArrowLeft",ARROW_RIGHT:"ArrowRight",DELETE:"Delete",BACKSPACE:"Backspace"};function h(r,e="polite"){const t=document.createElement("div");t.setAttribute("role","status"),t.setAttribute("aria-live",e),t.setAttribute("aria-atomic","true"),t.className="sr-only",t.textContent=r,document.body.appendChild(t),setTimeout(()=>{document.body.removeChild(t)},1e3)}const N={success(r,e=3e3){return h(r,"polite"),c.success(r,{duration:e,position:"bottom-center",style:{background:"#ffffff",color:"#1f2937",padding:"12px 16px",borderRadius:"8px",fontSize:"14px",borderBottom:"3px solid #10b981",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"},iconTheme:{primary:"#10b981",secondary:"#fff"}})},error(r,e=4e3){return h(r,"assertive"),c.error(r,{duration:e,position:"bottom-center",style:{background:"#ffffff",color:"#1f2937",padding:"12px 16px",borderRadius:"8px",fontSize:"14px",borderBottom:"3px solid #ef4444",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"},iconTheme:{primary:"#ef4444",secondary:"#fff"}})},loading(r){return c.loading(r,{position:"bottom-center",style:{background:"#ffffff",color:"#1f2937",padding:"12px 16px",borderRadius:"8px",fontSize:"14px",borderBottom:"3px solid #3b82f6",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"},iconTheme:{primary:"#3b82f6",secondary:"#fff"}})},info(r,e=3e3){return c(r,{duration:e,position:"bottom-center",icon:"ℹ️",style:{background:"#ffffff",color:"#1f2937",padding:"12px 16px",borderRadius:"8px",fontSize:"14px",borderBottom:"3px solid #3b82f6",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"}})},warning(r,e=4e3){return c(r,{duration:e,position:"bottom-center",icon:"⚠️",style:{background:"#ffffff",color:"#1f2937",padding:"12px 16px",borderRadius:"8px",fontSize:"14px",borderBottom:"3px solid #f59e0b",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"}})},dismiss(r){c.dismiss(r)},dismissAll(){c.dismiss()},promise(r,e){return c.promise(r,e,{style:{padding:"12px 16px",borderRadius:"8px",fontSize:"14px"},position:"bottom-center"})}};class T{constructor(e={}){p(this,"apiKey");p(this,"config");p(this,"retryConfig");this.config={temperature:e.temperature??d.DEFAULT_TEMPERATURE,maxTokens:e.maxTokens??d.DEFAULT_MAX_TOKENS,topK:e.topK??d.DEFAULT_TOP_K,topP:e.topP??d.DEFAULT_TOP_P},this.retryConfig={...E,onRetry:(t,a,o)=>{N.loading(`Connection issue. Retrying (${t}/${a})...`,2e3)}}}async executeWithRetry(e,t){const a=t?{...this.retryConfig,...t}:this.retryConfig;return w(e,a)}async generateFormResponses(e,t){return this.executeWithRetry(async()=>{const a=f.buildStructuredFormPrompt(e,t),o=await this.generateContent(a);return f.parseStructuredFormResponse(o,t.length)})}}class v extends T{constructor(){super()}getName(){return"Chrome AI"}requiresApiKey(){return!1}static async isAvailable(){var e;try{return(e=window.ai)!=null&&e.languageModel?(await window.ai.languageModel.capabilities()).available!=="no":!1}catch{return!1}}static async getAvailabilityStatus(){var e;try{if(!((e=window.ai)!=null&&e.languageModel))return{available:!1,status:"not-supported",message:"Chrome AI is not supported in this browser. Please use Chrome 127+ and enable the required flags."};const t=await window.ai.languageModel.capabilities();return t.available==="readily"?{available:!0,status:"readily",message:"Chrome AI is ready to use!"}:t.available==="after-download"?{available:!0,status:"after-download",message:"Chrome AI will download on first use (may take a few minutes)."}:{available:!1,status:"no",message:"Chrome AI is not available. Please enable the required Chrome flags."}}catch{return{available:!1,status:"not-supported",message:"Unable to check Chrome AI status. Please ensure you are using Chrome 127+ with AI features enabled."}}}async generateContent(e){return this.executeWithRetry(async()=>{var t;try{if(!((t=window.ai)!=null&&t.languageModel))throw new l(u.UNAVAILABLE,"Chrome AI is not available. Please use Chrome 127+ and enable the Prompt API.",this.getName());const a=await window.ai.languageModel.create({temperature:this.config.temperature,topK:this.config.topK}),o=await a.prompt(e);return a.destroy(),o}catch(a){throw a instanceof l?a:a instanceof Error?a.message.includes("not available")?new l(u.UNAVAILABLE,"Chrome AI is not available. Please enable it in chrome://flags or use another AI provider.",this.getName()):new l(u.UNKNOWN,`Chrome AI Error: ${a.message}`,this.getName(),a):new l(u.UNKNOWN,"Chrome AI request failed. Please try another AI provider.",this.getName())}})}async testConnection(){return this.executeWithRetry(async()=>{var e;try{if(!((e=window.ai)!=null&&e.languageModel))throw new l(u.UNAVAILABLE,"Chrome AI is not available",this.getName());if((await window.ai.languageModel.capabilities()).available==="no")throw new l(u.UNAVAILABLE,"Chrome AI is not available. Please enable the Prompt API in chrome://flags",this.getName());const a=await window.ai.languageModel.create(),o=await a.prompt('Say "OK"');return a.destroy(),o.length>0}catch(t){throw t}})}}const U=Object.freeze(Object.defineProperty({__proto__:null,ChromeAI:v},Symbol.toStringTag,{value:"Module"}));export{D as A,T as B,v as C,M as K,l as P,C as R,N as T,d as a,u as b,S as c,_ as d,P as e,h as f,U as g};
