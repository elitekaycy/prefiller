import{M as Q,_ as g,A as H,q as $,y as P,k as V,d as W}from"./vendor-preact-B9_ueiDX.js";let G={data:""},J=e=>{if(typeof window=="object"){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||G},X=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,ee=/\/\*[^]*?\*\/|  +/g,L=/\n+/g,x=(e,t)=>{let a="",i="",s="";for(let o in e){let r=e[o];o[0]=="@"?o[1]=="i"?a=o+" "+r+";":i+=o[1]=="f"?x(r,o):o+"{"+x(r,o[1]=="k"?"":t)+"}":typeof r=="object"?i+=x(r,t?t.replace(/([^,])+/g,n=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,l=>/&/.test(l)?l.replace(/&/g,n):n?n+" "+l:l)):o):r!=null&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=x.p?x.p(o,r):o+":"+r+";")}return a+(t&&s?t+"{"+s+"}":s)+i},b={},S=e=>{if(typeof e=="object"){let t="";for(let a in e)t+=a+S(e[a]);return t}return e},te=(e,t,a,i,s)=>{let o=S(e),r=b[o]||(b[o]=(l=>{let c=0,u=11;for(;c<l.length;)u=101*u+l.charCodeAt(c++)>>>0;return"go"+u})(o));if(!b[r]){let l=o!==e?e:(c=>{let u,d,p=[{}];for(;u=X.exec(c.replace(ee,""));)u[4]?p.shift():u[3]?(d=u[3].replace(L," ").trim(),p.unshift(p[0][d]=p[0][d]||{})):p[0][u[1]]=u[2].replace(L," ").trim();return p[0]})(e);b[r]=x(s?{["@keyframes "+r]:l}:l,a?"":"."+r)}let n=a&&b.g?b.g:null;return a&&(b.g=b[r]),((l,c,u,d)=>{d?c.data=c.data.replace(d,l):c.data.indexOf(l)===-1&&(c.data=u?l+c.data:c.data+l)})(b[r],t,i,n),r},ae=(e,t,a)=>e.reduce((i,s,o)=>{let r=t[o];if(r&&r.call){let n=r(a),l=n&&n.props&&n.props.className||/^go/.test(n)&&n;r=l?"."+l:n&&typeof n=="object"?n.props?"":x(n,""):n===!1?"":n}return i+s+(r??"")},"");function A(e){let t=this||{},a=e.call?e(t.p):e;return te(a.unshift?a.raw?ae(a,[].slice.call(arguments,1),t.p):a.reduce((i,s)=>Object.assign(i,s&&s.call?s(t.p):s),{}):a,J(t.target),t.g,t.o,t.k)}let R,T,_;A.bind({g:1});let v=A.bind({k:1});function re(e,t,a,i){x.p=t,R=e,T=a,_=i}function w(e,t){let a=this||{};return function(){let i=arguments;function s(o,r){let n=Object.assign({},o),l=n.className||s.className;a.p=Object.assign({theme:T&&T()},n),a.o=/ *go\d+/.test(l),n.className=A.apply(a,i)+(l?" "+l:"");let c=e;return e[0]&&(c=n.as||e,delete n.as),_&&c[0]&&_(n),R(c,n)}return s}}var ie=e=>typeof e=="function",z=(e,t)=>ie(e)?e(t):e,oe=(()=>{let e=0;return()=>(++e).toString()})(),q=(()=>{let e;return()=>{if(e===void 0&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),se=20,E="default",B=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(r=>r.id===t.toast.id?{...r,...t.toast}:r)};case 2:let{toast:i}=t;return B(e,{type:e.toasts.find(r=>r.id===i.id)?1:0,toast:i});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(r=>r.id===s||s===void 0?{...r,dismissed:!0,visible:!1}:r)};case 4:return t.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(r=>r.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(r=>({...r,pauseDuration:r.pauseDuration+o}))}}},j=[],U={toasts:[],pausedAt:void 0,settings:{toastLimit:se}},h={},Y=(e,t=E)=>{h[t]=B(h[t]||U,e),j.forEach(([a,i])=>{a===t&&i(h[t])})},Z=e=>Object.keys(h).forEach(t=>Y(e,t)),ne=e=>Object.keys(h).find(t=>h[t].toasts.some(a=>a.id===e)),N=(e=E)=>t=>{Y(t,e)},le={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},de=(e={},t=E)=>{let[a,i]=W(h[t]||U),s=H(h[t]);P(()=>(s.current!==h[t]&&i(h[t]),j.push([t,i]),()=>{let r=j.findIndex(([n])=>n===t);r>-1&&j.splice(r,1)}),[t]);let o=a.toasts.map(r=>{var n,l,c;return{...e,...e[r.type],...r,removeDelay:r.removeDelay||((n=e[r.type])==null?void 0:n.removeDelay)||(e==null?void 0:e.removeDelay),duration:r.duration||((l=e[r.type])==null?void 0:l.duration)||(e==null?void 0:e.duration)||le[r.type],style:{...e.style,...(c=e[r.type])==null?void 0:c.style,...r.style}}});return{...a,toasts:o}},ce=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(a==null?void 0:a.id)||oe()}),k=e=>(t,a)=>{let i=ce(t,e,a);return N(i.toasterId||ne(i.id))({type:2,toast:i}),i.id},m=(e,t)=>k("blank")(e,t);m.error=k("error");m.success=k("success");m.loading=k("loading");m.custom=k("custom");m.dismiss=(e,t)=>{let a={type:3,toastId:e};t?N(t)(a):Z(a)};m.dismissAll=e=>m.dismiss(void 0,e);m.remove=(e,t)=>{let a={type:4,toastId:e};t?N(t)(a):Z(a)};m.removeAll=e=>m.remove(void 0,e);m.promise=(e,t,a)=>{let i=m.loading(t.loading,{...a,...a==null?void 0:a.loading});return typeof e=="function"&&(e=e()),e.then(s=>{let o=t.success?z(t.success,s):void 0;return o?m.success(o,{id:i,...a,...a==null?void 0:a.success}):m.dismiss(i),s}).catch(s=>{let o=t.error?z(t.error,s):void 0;o?m.error(o,{id:i,...a,...a==null?void 0:a.error}):m.dismiss(i)}),e};var ue=1e3,pe=(e,t="default")=>{let{toasts:a,pausedAt:i}=de(e,t),s=H(new Map).current,o=$((d,p=ue)=>{if(s.has(d))return;let f=setTimeout(()=>{s.delete(d),r({type:4,toastId:d})},p);s.set(d,f)},[]);P(()=>{if(i)return;let d=Date.now(),p=a.map(f=>{if(f.duration===1/0)return;let D=(f.duration||0)+f.pauseDuration-(d-f.createdAt);if(D<0){f.visible&&m.dismiss(f.id);return}return setTimeout(()=>m.dismiss(f.id,t),D)});return()=>{p.forEach(f=>f&&clearTimeout(f))}},[a,i,t]);let r=$(N(t),[t]),n=$(()=>{r({type:5,time:Date.now()})},[r]),l=$((d,p)=>{r({type:1,toast:{id:d,height:p}})},[r]),c=$(()=>{i&&r({type:6,time:Date.now()})},[i,r]),u=$((d,p)=>{let{reverseOrder:f=!1,gutter:D=8,defaultPosition:M}=p||{},I=a.filter(y=>(y.position||M)===(d.position||M)&&y.height),K=I.findIndex(y=>y.id===d.id),F=I.filter((y,C)=>C<K&&y.visible).length;return I.filter(y=>y.visible).slice(...f?[F+1]:[0,F]).reduce((y,C)=>y+(C.height||0)+D,0)},[a]);return P(()=>{a.forEach(d=>{if(d.dismissed)o(d.id,d.removeDelay);else{let p=s.get(d.id);p&&(clearTimeout(p),s.delete(d.id))}})},[a,o]),{toasts:a,handlers:{updateHeight:l,startPause:n,endPause:c,calculateOffset:u}}},me=v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,fe=v`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ge=v`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ye=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${me} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${fe} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${ge} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,he=v`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,be=w("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${he} 1s linear infinite;
`,ve=v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,xe=v`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,we=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ve} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${xe} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,$e=w("div")`
  position: absolute;
`,ke=w("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,De=v`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Oe=w("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${De} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,je=({toast:e})=>{let{icon:t,type:a,iconTheme:i}=e;return t!==void 0?typeof t=="string"?g(Oe,null,t):t:a==="blank"?null:g(ke,null,g(be,{...i}),a!=="loading"&&g($e,null,a==="error"?g(ye,{...i}):g(we,{...i})))},ze=e=>`
0% {transform: translate3d(0,${e*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Ae=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e*-150}%,-1px) scale(.6); opacity:0;}
`,Ne="0%{opacity:0;} 100%{opacity:1;}",Ie="0%{opacity:1;} 100%{opacity:0;}",Ce=w("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Pe=w("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Te=(e,t)=>{let a=e.includes("top")?1:-1,[i,s]=q()?[Ne,Ie]:[ze(a),Ae(a)];return{animation:t?`${v(i)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${v(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},_e=Q(({toast:e,position:t,style:a,children:i})=>{let s=e.height?Te(e.position||t||"top-center",e.visible):{opacity:0},o=g(je,{toast:e}),r=g(Pe,{...e.ariaProps},z(e.message,e));return g(Ce,{className:e.className,style:{...s,...a,...e.style}},typeof i=="function"?i({icon:o,message:r}):g(V,null,o,r))});re(g);var Ee=({id:e,className:t,style:a,onHeightUpdate:i,children:s})=>{let o=$(r=>{if(r){let n=()=>{let l=r.getBoundingClientRect().height;i(e,l)};n(),new MutationObserver(n).observe(r,{subtree:!0,childList:!0,characterData:!0})}},[e,i]);return g("div",{ref:o,className:t,style:a},s)},Me=(e,t)=>{let a=e.includes("top"),i=a?{top:0}:{bottom:0},s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:q()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...i,...s}},Fe=A`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,O=16,He=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:i,children:s,toasterId:o,containerStyle:r,containerClassName:n})=>{let{toasts:l,handlers:c}=pe(a,o);return g("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:O,left:O,right:O,bottom:O,pointerEvents:"none",...r},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(u=>{let d=u.position||t,p=c.calculateOffset(u,{reverseOrder:e,gutter:i,defaultPosition:t}),f=Me(d,p);return g(Ee,{id:u.id,key:u.id,onHeightUpdate:c.updateHeight,className:u.visible?Fe:"",style:f},u.type==="custom"?z(u.message,u):s?s(u):g(_e,{toast:u,position:d}))}))},Se=m;export{He as F,Se as z};
